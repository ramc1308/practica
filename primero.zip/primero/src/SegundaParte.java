public class SegundaParte {
    public static void main(String [] args)
    {
        Coche miCoche= new Coche();
        System.out.println("Numero de Puerta Inicial "+miCoche.Puerta);
        miCoche.AgregarPuerta();
        System.out.println("Numero de Puerta Final "+miCoche.Puerta);
    }
}
class  Coche{
    public int Puerta=0;

    public void AgregarPuerta(){
        this.Puerta++;
    }
}