public class primero {
    public static void main(String [] args)
    {
        int v1=100;
        int v2=30;
        int v3=30;
        var valor = sumar(v1,v2,v3);
        System.out.println(valor);
    }

    public static int sumar(int a, int b,int c)
    {
        return a+b+c;
    }
}
